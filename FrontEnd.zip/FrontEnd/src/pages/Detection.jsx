import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { FaArrowLeft } from "react-icons/fa";

const Detection = ({ isLoggedIn }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // ... rest of the code stays the same ...
};
